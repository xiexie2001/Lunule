# Block Device Abstraction Layer {#bdev}

- @ref bdev_getting_started
