// -*- mode:C++; tab-width:8; c-basic-offset:2; indent-tabs-mode:t -*-
// vim: ts=8 sw=2 smarttab

#ifndef CEPH_RGW_REST_ADMIN_H
#define CEPH_RGW_REST_ADMIN_H


class RGWRESTMgr_Admin : public RGWRESTMgr {
public:
  RGWRESTMgr_Admin() {}
  ~RGWRESTMgr_Admin() override {}
};


#endif
