// -*- mode:C++; tab-width:8; c-basic-offset:2; indent-tabs-mode:t -*-
// vim: ts=8 sw=2 smarttab

#ifndef RGW_OS_LIB_H
#define RGW_OS_LIB_H

#include <functional>
#include "rgw_common.h"
#include "rgw_lib.h"


#endif /* RGW_OS_LIB_H */
