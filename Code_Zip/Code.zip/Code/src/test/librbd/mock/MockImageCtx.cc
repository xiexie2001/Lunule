// -*- mode:C++; tab-width:8; c-basic-offset:2; indent-tabs-mode:t -*-
// vim: ts=8 sw=2 smarttab

#include "test/librbd/mock/MockImageCtx.h"

namespace librbd {

MockImageCtx* MockImageCtx::s_instance = nullptr;

} // namespace librbd
