import ceph_brag

# This file tests nothing (yet) except for being able to import ceph_brag
# correctly and thus ensuring somewhat that it will work under different Python
# versions. You must write unittests here so that code has adequate coverage.

class TestCephBrag(object):

    def test_basic(self):
        assert True
